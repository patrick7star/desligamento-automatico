
"""
 Para encurtar o código de testes, coloco 
 aqui textos usados lá, alogarem em muitas
 linhas a parte de testes. No fim, é uma
 tarefa de apenas importar tal módulo para
 usa-lôs em testes.
"""


poemaI = (
   """rosas são vermelhas
   \rvioletas são azuis
   \rseu chapéu é vermelho
   \re o meu é azul"""
)

poemaII = (
   "rosas são vermelhas \n violetas" +
   "são azuis \n seu chapéu é preto\n" +
   "e o meu cheira a cajú\n \n\n\n"
)

texto = (
   """ hoje abri a porta do inferno para 
   \ralgo inacreditávelmente ruim
   \ruma espécime de diabo com mãe natureza
   \ra pior coisa que pode existir em mundos 
   \rmágicos simulacionais ou materialistas
   \rcomo o nosso"""
)

nome = "Júlia Alves Fernandes Balú"
